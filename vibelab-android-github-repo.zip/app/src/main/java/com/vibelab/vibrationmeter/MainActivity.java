package com.vibelab.vibrationmeter;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Vibrator vibrator;

    private TextView tvPower, tvRms, tvPeakG, tvSeverity;
    private Button btnVibrateMax, btnVibratePulse, btnStopVibrate;

    private float peakMag = 0f;
    private final float[] recentMags = new float[50];
    private int sampleIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvPower = findViewById(R.id.tvPower);
        tvRms = findViewById(R.id.tvRms);
        tvPeakG = findViewById(R.id.tvPeakG);
        tvSeverity = findViewById(R.id.tvSeverity);
        btnVibrateMax = findViewById(R.id.btnVibrateMax);
        btnVibratePulse = findViewById(R.id.btnVibratePulse);
        btnStopVibrate = findViewById(R.id.btnStopVibrate);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
            if (accelerometer == null) {
                accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            vibrator = vm.getDefaultVibrator();
        } else {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }

        btnVibrateMax.setOnClickListener(v -> triggerVibration(1000, 255));
        btnVibratePulse.setOnClickListener(v -> {
            long[] timings = new long[]{0, 150, 100, 250, 100, 400};
            int[] amplitudes = new int[]{0, 180, 0, 220, 0, 255};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator != null && vibrator.hasAmplitudeControl()) {
                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1));
            } else if (vibrator != null) {
                vibrator.vibrate(timings, -1);
            }
        });

        btnStopVibrate.setOnClickListener(v -> {
            if (vibrator != null) vibrator.cancel();
        });
    }

    private void triggerVibration(long durationMs, int amplitude) {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int amp = vibrator.hasAmplitudeControl() ? amplitude : VibrationEffect.DEFAULT_AMPLITUDE;
            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amp));
        } else {
            vibrator.vibrate(durationMs);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (vibrator != null) vibrator.cancel();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];
        float mag = (float) Math.sqrt(x * x + y * y + z * z);

        recentMags[sampleIndex % recentMags.length] = mag;
        sampleIndex++;

        float sumSq = 0;
        for (float m : recentMags) sumSq += (m * m);
        float rms = (float) Math.sqrt(sumSq / recentMags.length);

        if (mag > peakMag) peakMag = mag;
        float peakG = peakMag / 9.80665f;

        tvPower.setText(String.format("%.2f m/s²", mag));
        tvRms.setText(String.format("RMS: %.2f m/s²", rms));
        tvPeakG.setText(String.format("Peak: %.2f G (%.2f m/s²)", peakG, peakMag));

        if (rms < 1.5f) {
            tvSeverity.setText("ISO Zone A (Ambient Floor)");
        } else if (rms < 5.5f) {
            tvSeverity.setText("ISO Zone B (Normal Haptic Vibration)");
        } else if (rms < 12.0f) {
            tvSeverity.setText("ISO Zone C (Strong Mechanical Vibration)");
        } else {
            tvSeverity.setText("ISO Zone D (Severe Shock / Resonance)");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}
