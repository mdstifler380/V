# VibeLab Pro — Android Vibration Power Analyzer

A native Android application with GitHub Actions CI configured to automatically compile an installable `.apk` file.

## How to Get Your APK via GitHub:
1. Create a new GitHub repository (public or private).
2. Upload or push all files in this folder to your repository.
3. GitHub Actions will trigger automatically upon commit.
4. Go to the **Actions** tab in your repository.
5. Click the latest **Build Debug APK** run.
6. Under **Artifacts**, download **VibeLab-Pro-vibration-app.zip**.
7. Extract the ZIP on your phone to get `app-debug.apk` and tap to install!
